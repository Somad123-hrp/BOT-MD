import { reply } from "../../lib/utils.js";
import config from "../../config.js";

async function handle(sock, messageInfo) {
  const { m } = messageInfo;

  const text = `╭「 𝗦𝗖𝗥𝗜𝗣𝗧 𝗛𝗔𝗕𝗜𝗕𝗜𝗛 𝗦𝗧𝗢𝗥𝗘 」
│
│◧ ᴠᴇʀꜱɪᴏɴ : ${global.version}
│◧ ᴛʏᴘᴇ ᴘʟᴜɢɪɴꜱ ᴇꜱᴍ
│◧ ɴᴏ ᴇɴᴄ 100%
│◧ ɴᴏ ʙᴜɢ & ɴᴏ ᴇʀʀᴏʀ 
│◧ ꜰʀᴇᴇ ᴀᴘɪᴋᴇʏ
│◧ ꜰʀᴇᴇ ᴜᴘᴅᴀᴛᴇ
│◧ ʙɪꜱᴀ ʀᴜɴ ᴅɪ ᴘᴀɴᴇʟ
╰────────────────────────◧

╭「 Nomor Onwer 」

◧ wa.me/62881026849093`;

  await reply(m, text);
}

export default {
  handle,
  Commands: ["sc", "script"],
  OnlyPremium: false,
  OnlyOwner: false,
};
